from .NetCalculate import calculate_network
